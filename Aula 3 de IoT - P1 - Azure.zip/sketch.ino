#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

// --- MAPEAMENTO DE PINOS ---
#define DHTPIN 12        // Pino digital do sensor DHT22
#define DHTTYPE DHT22    
#define LED_PIN 2        // Pino do LED indicador de status da conexão MQTT

DHT dht(DHTPIN, DHTTYPE);

// --- CONFIGURAÇÕES DA REDE WI-FI ---
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// --- CONFIGURAÇÕES NATIVAS DO AZURE IOT HUB ---
const char* iot_hub_name = "iot-aula-hub-prd-001";
const char* device_id    = "dev-esp32-sensor-dht22";

// Endereço do broker (HostName do Azure IoT Hub)
const char* mqtt_server  = "iot-aula-hub-prd-001.azure-devices.net";
const int   mqtt_port    = 8883; // Porta segura TLS

// Username padrão exigido pelo Azure IoT Hub
const char* mqtt_user    = "USERNAME GERADO AQUI";

// Cole aqui o Token SAS completo gerado no Azure CLI
const char* sas_token    = "SEU TOKEN AQUI";

// Tópico padrão obrigatório do Azure para telemetria de dispositivos
// Ex: devices/dev-esp32-sensor-dht22/messages/events/$.ct=application%2Fjson&$.ce=utf-8
const char* mqtt_topic = "SEU TÓPICO AQUI";

WiFiClientSecure espClient;
PubSubClient client(espClient);

unsigned long lastMsg = 0;
const long interval = 5000; // Envio a cada 5 segundos

void setup_wifi() {
  delay(10);
  Serial.println("\nConectando ao Wi-Fi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\n[Wi-Fi] Conectado!");
  Serial.print("[Wi-Fi] IP: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    digitalWrite(LED_PIN, LOW); // Garante LED apagado se desconectado
    Serial.print("Tentando conectar diretamente ao Azure IoT Hub...");

    // No Azure, o Client ID DEVE ser exatamente o Device ID cadastrado
    if (client.connect(device_id, mqtt_user, sas_token)) {
      Serial.println("\n[AZURE MQTT] Conectado com sucesso ao Azure IoT Hub!");
      digitalWrite(LED_PIN, HIGH); // Liga o LED indicando conexão estabelecida
    } else {
      Serial.print("\n[AZURE MQTT] Falha. Código de erro: ");
      Serial.print(client.state());
      Serial.println(" -> Recompilando tentativa em 5 segundos...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  dht.begin();

  // Desabilita verificação de certificado raiz SSL para testes no Wokwi
  espClient.setInsecure();

  // Aumenta os buffers de transmissão da biblioteca para suportar o payload e o pacote TLS do Azure
  client.setBufferSize(1024);

  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    digitalWrite(LED_PIN, LOW);
    reconnect();
  } else {
    digitalWrite(LED_PIN, HIGH);
  }

  client.loop();

  unsigned long now = millis();
  if (now - lastMsg > interval) {
    lastMsg = now;

    float umidade = dht.readHumidity();
    float temperatura = dht.readTemperature();

    if (isnan(umidade) || isnan(temperatura)) {
      Serial.println("[ERRO] Falha ao ler o sensor DHT22!");
      return;
    }

    // Estruturação do Payload JSON
    JsonDocument doc;
    doc["temperatura"] = temperatura;
    doc["umidade"] = umidade;
    doc["dispositivo"] = device_id;

    char jsonBuffer[512];
    serializeJson(doc, jsonBuffer);

    Serial.print("[AZURE TELEMETRIA] Enviando dados: ");
    Serial.println(jsonBuffer);

    // Publicação direta no Azure IoT Hub
    if (client.publish(mqtt_topic, jsonBuffer)) {
      Serial.println("[AZURE MQTT] Mensagem entregue com sucesso!");
    } else {
      Serial.println("[AZURE MQTT] Erro no envio da mensagem!");
    }
  }
}