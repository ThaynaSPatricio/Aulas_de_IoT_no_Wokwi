#include <WiFi.h>
#include <WiFiClientSecure.h> // Biblioteca necessária para comunicação SSL/TLS com HiveMQ Cloud
#include <PubSubClient.h>
#include <DHT.h>
#include <ArduinoJson.h>

// ============================================================================
// MAPEAMENTO DE PINOS E SENSORES 
// [Atende ao RF01: Leitura simultânea de 3 sensores distintos]
// ============================================================================
#define DHTPIN 15             // Pino GPIO15 -> Sensor DHT22 (Temperatura)
#define DHTTYPE DHT22         
#define LDR_PIN 34            // Pino analógico GPIO34 -> LDR (Tacômetro / Rotação simulada)
#define POT_PIN 35            // Pino analógico GPIO35 -> Potenciômetro (Vibração simulada)

// ============================================================================
// CONFIGURAÇÃO DE REDE E CREDENCIAIS HIVEMQ CLOUD
// [Atende ao RF03: Conexão Wi-Fi e publicação MQTT no HiveMQ Cloud]
// [Atende ao RNF01/RNF03: Autenticação de credenciais e uso de camada gratuita]
// ============================================================================
const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// URL do seu Cluster HiveMQ Cloud
const char* MQTT_BROKER = "SEU BROKER AQUI"; 
const int MQTT_PORT = 8883; // Porta padrão TLS/SSL do HiveMQ Cloud

// Substitua pelas credenciais criadas em "Credentials" na sua conta HiveMQ Cloud
const char* MQTT_USER = "USUÁRIO AQUI";
const char* MQTT_PASSWORD = "SENHA DO USUÁRIO AQUI";

// Client ID Fixo e Global
const char* MQTT_CLIENT_ID = "CRIE AQUI O SEU ID"; // Evite utilizar espaço

// Tópico de envio
const char* MQTT_TOPIC = "SEU TÓPICO AQUI"; // Exemplo: 'industria/motor/telemetria'

// Instâncias
DHT dht(DHTPIN, DHTTYPE);
WiFiClientSecure espClient; // Cliente seguro para porta 8883 (TLS)
PubSubClient client(espClient);

unsigned long lastMsgTime = 0;
const long interval = 2000; // Intervalo de envio (2 segundos)

// Conexão com a rede local [Atende ao RF03]
void setupWiFi() {
  Serial.print("Conectando ao Wi-Fi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWi-Fi Conectado com sucesso!");
}

// Conexão e manutenção com autenticação no broker MQTT [Atende ao RF03 e RNF01]
void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("Conectando ao HiveMQ Cloud com ID: ");
    Serial.print(MQTT_CLIENT_ID);
    
    // Autenticação utilizando ClientID, Usuário e Senha
    if (client.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASSWORD)) {
      Serial.println(" -> Autenticado e Conectado com sucesso!");
    } else {
      Serial.print(" -> Falha na conexão. Código erro=");
      Serial.print(client.state());
      Serial.println(". Nova tentativa em 5s...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  setupWiFi();

  // Ignora a validação de certificado CA raiz para facilitar os testes no Wokwi
  espClient.setInsecure();

  client.setServer(MQTT_BROKER, MQTT_PORT);
}

void loop() {
  if (!client.connected()) {
    reconnectMQTT();
  }
  client.loop();

  unsigned long now = millis();
  if (now - lastMsgTime > interval) {
    lastMsgTime = now;

    // ========================================================================
    // LEITURA DOS TRÊS SENSORES SIMULTANEAMENTE 
    // [Atende ao RF01: Coleta simultânea das três grandezas físicas do motor]
    // ========================================================================

    // 1. Leitura do DHT22 -> Temperatura (°C)
    float temp = dht.readTemperature();
    if (isnan(temp)) temp = 0.0;
    temp = round(temp * 10.0) / 10.0;

    // 2. Leitura do LDR -> Tacômetro óptico (0 a 3000 RPM)
    int ldrRaw = analogRead(LDR_PIN);
    int rpm = map(ldrRaw, 0, 4095, 0, 3000);

    // 3. Leitura do Potenciômetro -> Vibração (0 a 100%)
    int potRaw = analogRead(POT_PIN);
    int vibracao = map(potRaw, 0, 4095, 0, 100);

    // ========================================================================
    // FORMATAÇÃO DO PAYLOAD EM JSON
    // [Atende ao RF02: Empacotamento das três medições num único JSON]
    // ========================================================================
    StaticJsonDocument<128> doc;
    doc["temperatura"] = temp;
    doc["rpm"] = rpm;
    doc["vibracao"] = vibracao;

    char payload[128];
    serializeJson(doc, payload);

    // ========================================================================
    // PUBLICAÇÃO DA MENSAGEM NO BROKER MQTT
    // [Atende ao RF03: Publicar o payload JSON no tópico do HiveMQ Cloud]
    // ========================================================================
    client.publish(MQTT_TOPIC, payload);
    
    Serial.print("Payload JSON enviado ao HiveMQ Cloud: ");
    Serial.println(payload);
  }
}