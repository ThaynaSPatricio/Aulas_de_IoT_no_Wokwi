/**
IFRJ Campus Volta Redonda - RJ
Pós graduação em Automação Industrial e Robótica
Desenvolvido pela aluna: Thayná Patricio
Professor Orientador: Profº Doutor Leonardo Vidal

Aula 2 - Prática 2
**/

// ==============================================================================
// INCLUSÃO DE BIBLIOTECAS
// ==============================================================================
#include <WiFi.h>           
#include <PubSubClient.h>   

// ==============================================================================
// CONFIGURAÇÕES DE REDE WI-FI E MQTT
// ==============================================================================
const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883; 

const char* topic_publish = "DIGITE O SEU AQUI";
const char* topic_subscribe = "DIGITE O SEU AQUI";
String clientId = "DIGITE O SEU AQUI";

// ==============================================================================
// DEFINIÇÃO DOS PINOS
// ==============================================================================
const int pinoLED = 2; // Define que o LED está conectado ao pino GPIO 2

// ==============================================================================
// OBJETOS E VARIÁVEIS GERAIS
// ==============================================================================
WiFiClient espClient;               
PubSubClient client(espClient);     
unsigned long lastMsg = 0;          

void setup_wifi() {
  delay(10);
  Serial.println(); 
  Serial.print("Conectando-se a rede: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password); 

  while (WiFi.status() != WL_CONNECTED) {
    delay(500); 
    Serial.print("."); 
  }

  Serial.println("");
  Serial.println("WiFi conectado com sucesso!");
  Serial.print("Endereço IP recebido: ");
  Serial.println(WiFi.localIP()); 
}

// ==============================================================================
// FUNÇÃO: RECEBER MENSAGENS (CALLBACK) - ATUALIZADA
// ==============================================================================
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Mensagem recebida no tópico [");
  Serial.print(topic);
  Serial.print("]: ");
  
  String messageTemp; 
  
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]); 
    messageTemp += (char)payload[i]; 
  }
  Serial.println(); 
  
  // ==============================================================================
  // LÓGICA PARA LIGAR E DESLIGAR O LED
  // ==============================================================================
  if (messageTemp == "Ligar") {
    digitalWrite(pinoLED, HIGH); // Manda energia para o pino 2
    Serial.println("--> Comando aceito: LED LIGADO!");
  } 
  else if (messageTemp == "Desligar") {
    digitalWrite(pinoLED, LOW);  // Corta a energia do pino 2
    Serial.println("--> Comando aceito: LED DESLIGADO!");
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Tentando conexão com o broker MQTT...");
    
    if (client.connect(clientId.c_str())) {
      Serial.println("Conectado ao broker!");
      client.publish(topic_publish, "ESP32 Conectado no Wokwi e pronto!");
      client.subscribe(topic_subscribe);
    } else {
      Serial.print("Falhou, erro=");
      Serial.print(client.state());
      Serial.println(" Tentando novamente em 5 segundos...");
      delay(5000); 
    }
  }
}

void setup() {
  Serial.begin(115200); 
  
  // ==============================================================================
  // CONFIGURAÇÃO DO HARDWARE
  // ==============================================================================
  pinMode(pinoLED, OUTPUT);    // Define o pino do LED como SAÍDA de energia
  digitalWrite(pinoLED, LOW);  // Garante que o ESP32 inicie com o LED apagado
  
  setup_wifi(); 
  client.setServer(mqtt_server, mqtt_port); 
  client.setCallback(callback); 
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  
  unsigned long now = millis(); 
  if (now - lastMsg > 5000) {
    lastMsg = now; 
    
    String msg = "Contador de tempo Wokwi: " + String(now/1000) + "s";
    client.publish(topic_publish, msg.c_str()); 
  }
}