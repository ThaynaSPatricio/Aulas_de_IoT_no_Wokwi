/**
IFRJ Campus Volta Redonda - RJ
Pós graduação em Automação Industrial e Robótica
Desenvolvido pela aluna: Thayná Patricio
Professor Orientador: Profº Doutor Leonardo Vidal

Aula 1 - Prática 3
**/

#include <WiFi.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <HTTPClient.h> // Biblioteca para requisições HTTP
#include <ArduinoJson.h>  // Biblioteca para tratar o JSON da API

// --- CONFIGURAÇÕES DA API ---
const String apiKey = "SUA CHAVE AQUI"; // Substitua pela sua chave da API
const String cidade = "Volta%20Redonda"; // Para cidades com nome composto é necessário susbtitui o espaço por %20
const String estado = "BR"; // Usar código do país

#define SCREEN_WIDTH 128 // Define a largura do display em pixels
#define SCREEN_HEIGHT 64 // Define a altura do display em pixels

// Cria o objeto 'display' passando as dimensões e o tipo de comunicação (&Wire)
// O valor -1 indica que o display não possui um pino de Reset físico dedicado
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setDisplay(String cidade, String estado, String temperatura, String umidade){
  display.clearDisplay(); // Limpa o buffer do display (remove o logo da Adafruit)
  display.setTextSize(1); // Define o tamanho da fonte (1 é o padrão, aprox. 6x8 pixels)
  display.setTextColor(SSD1306_WHITE); // Define a cor do texto (Branco no fundo preto)
  
  // Linha 1: Localização (Cidade - Estado)
  display.setCursor(0, 0); // Posiciona o "cursor" na coordenada X=0, Y=0 (canto superior esquerdo)
  display.print(cidade); // Escreve o texto no buffer interno
  display.print(" - ");
  display.println(estado);
  
  // Linha 2: Temperatura
  display.setCursor(0, 20); // Pula 20 pixels para baixo
  display.print("Temp: ");
  display.print(temperatura);
  display.write(247); // Desenha o símbolo de grau º
  display.println("C");
  
  // Linha 3: Umidade
  display.setCursor(0, 40); // Pula mais 20 pixels
  display.print("Umidade: ");
  display.print(umidade);
  display.println("%");
  
  display.display(); // Comando CRUCIAL: transfere o buffer para a tela física
}

void setup() {
  // Inicializa o display. O endereço 0x3C é o padrão para a maioria desses módulos OLED
  // SSD1306_SWITCHCAPVCC gera a tensão do display a partir de 3.3V internos
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { // Endereço 0x3C é o padrão
  Serial.println(F("Falha ao iniciar o SSD1306")); // Mensagem de erro caso a conexão falhe
    for(;;);
  }
  // Inicia a comunicação serial com velocidade de 9600 bps
  // Permite visualizar mensagens no Monitor Serial
  Serial.begin(9600);
  // Exibe mensagem inicial indicando tentativa de conexão
  Serial.print("Connecting to WiFi");
  /*
    Inicia a conexão WiFi:
    - "Wokwi-GUEST" → Nome da rede (SSID)
    - "" → Senha (vazia no simulador)
    - 6 → Canal da rede (opcional no Wokwi)
  */
  WiFi.begin("Wokwi-GUEST", "", 6);
  // Enquanto o status NÃO for conectado...
  while (WiFi.status() != WL_CONNECTED) {
    delay(100); // Aguarda 100 milissegundos
    Serial.print("."); // Imprime ponto para indicar tentativa de conexão
  }
  Serial.println(" Connected!"); // Exibe mensagem quando a conexão é estabelecida
  // cahamada da função que vai escrever mensagem no Display
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    // URL da requisição (metric = Celsius)
    String url = "http://api.openweathermap.org/data/2.5/weather?q=" + cidade + "," + estado + "&appid=" + apiKey + "&units=metric";

    http.begin(url);
    int httpCode = http.GET(); // Realiza a chamada GET

    if (httpCode > 0) {
      String payload = http.getString(); // Recebe o JSON bruto
      
      // Criando o objeto para "parsear" o JSON
      DynamicJsonDocument doc(1024);
      deserializeJson(doc, payload);

      // Extraindo os dados do JSON
      float temp = doc["main"]["temp"];
      int umid = doc["main"]["humidity"];
      String nomeCidade = doc["name"];

      // Atualiza o Display com dados REAIS
      setDisplay(nomeCidade, estado, String(temp, 1), String(umid));
      
      Serial.println("Dados atualizados!");
    } else {
      Serial.println("Erro na requisição HTTP");
    }
    http.end();
  }

  // A API gratuita tem limites, então vamos atualizar apenas a cada 30 segundos
  delay(30000);
}