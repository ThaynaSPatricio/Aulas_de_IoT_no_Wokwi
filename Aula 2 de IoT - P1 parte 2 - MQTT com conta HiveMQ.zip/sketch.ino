/**
IFRJ Campus Volta Redonda - RJ
Pós graduação em Automação Industrial e Robótica
Desenvolvido pela aluna: Thayná Patricio
Professor Orientador: Profº Doutor Leonardo Vidal

Aula 2 - Prática 1 - parte 2
**/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

// --- DEFINIÇÃO DOS PINOS E SENSORES ---
#define DHTPIN 12        // Pino digital onde o sensor DHT22 está conectado
#define DHTTYPE DHT22    // Define o modelo do sensor
#define LED_PIN 2        // Pino do LED indicador de status da conexão MQTT

// Instância do sensor DHT
DHT dht(DHTPIN, DHTTYPE);

// --- CONFIGURAÇÕES DA REDE WI-FI ---
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// --- CONFIGURAÇÕES DO BROKER HIVEMQ CLOUD ---
const char* mqtt_server = "SEU SERVIRO HIVEMQ AQUI";
const int mqtt_port = 8883;                      // Porta segura (TLS)
const char* mqtt_user = "SEU USÁRIO AQUI";            
const char* mqtt_pass = "SUA SENHA AQUI";          
const char* mqtt_topic = "SEU TÓPICO AQUI"; // Tópico onde os dados serão publicados

// Clientes para comunicação de rede e MQTT
WiFiClientSecure espClient;
PubSubClient client(espClient);

// Variável para controle de tempo de envio sem travar o programa (non-blocking delay)
unsigned long lastMsg = 0;
const long interval = 5000; // Intervalo de envio em milissegundos (5 segundos)

// Função responsável por conectar ao Wi-Fi
void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Conectando a rede Wi-Fi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\n[Wi-Fi] Conectado com sucesso!");
  Serial.print("[Wi-Fi] Endereço IP: ");
  Serial.println(WiFi.localIP());
}

// Função responsável por gerenciar a conexão com o Broker MQTT
void reconnect() {
  // Loop executado enquanto estiver desconectado do MQTT
  while (!client.connected()) {
    // Garante que o LED fique APAGADO enquanto tenta conectar
    digitalWrite(LED_PIN, LOW);
    
    Serial.print("Tentando conectar ao Broker MQTT...");
    
    // Identificador único para a sessão do cliente
    String clientId = "ESP32-DHT22-";
    clientId += String(random(0xffff), HEX);

    // Tentativa de conexão com usuário e senha
    if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
      Serial.println("\n[MQTT] Conectado com sucesso!");
      
      // LIGA o LED assim que a conexão é estabelecida
      digitalWrite(LED_PIN, HIGH); 
    } else {
      Serial.print("\n[MQTT] Falha na conexão. Código de erro (state): ");
      Serial.print(client.state());
      Serial.println(" -> Nova tentativa em 5 segundos...");
      
      delay(5000);
    }
  }
}

void setup() {
  // Inicializa a comunicação serial para monitoramento
  Serial.begin(115200);

  // Configura o pino do LED como saída
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW); // Garante que o LED inicie apagado

  // Inicializa o sensor DHT22
  dht.begin();

  // Ignora verificação do certificado SSL para simulação
  espClient.setInsecure();

  // Conecta ao Wi-Fi
  setup_wifi();

  // Configura os parâmetros do servidor MQTT
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  // 1. Verificação da conexão MQTT
  if (!client.connected()) {
    digitalWrite(LED_PIN, LOW); // Apaga o LED se a conexão cair
    reconnect();
  } else {
    digitalWrite(LED_PIN, HIGH); // Mantém o LED aceso com a conexão ativa
  }
  
  // Mantém a comunicação MQTT ativa (escuta pacotes e envia keep-alive)
  client.loop();

  // 2. Leitura e Envio de dados temporizado (a cada 5 segundos)
  unsigned long now = millis();
  if (now - lastMsg > interval) {
    lastMsg = now;

    // Leitura da umidade e temperatura do DHT22
    float umidade = dht.readHumidity();
    float temperatura = dht.readTemperature();

    // Valida se a leitura do sensor foi bem-sucedida
    if (isnan(umidade) || isnan(temperatura)) {
      Serial.println("[ERRO] Falha ao ler os dados do sensor DHT22!");
      return;
    }

    // Criação da estrutura JSON
    JsonDocument doc;
    doc["temperatura"] = temperatura;
    doc["umidade"] = umidade;
    doc["dispositivo"] = "ESP32_Wokwi";

    // Serialização do JSON para String
    char jsonBuffer[512];
    serializeJson(doc, jsonBuffer);

    // Publicação dos dados no tópico MQTT
    Serial.print("[MQTT] Publicando mensagem: ");
    Serial.println(jsonBuffer);
    
    client.publish(mqtt_topic, jsonBuffer);
  }
}