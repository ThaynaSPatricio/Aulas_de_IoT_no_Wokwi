/**
IFRJ Campus Volta Redonda - RJ
Pós graduação em Automação Industrial e Robótica
Desenvolvido pela aluna: Thayná Patricio
Professor Orientador: Profº Doutor Leonardo Vidal

Aula 2 - Prática 3
**/

// ==============================================================================
// INCLUSÃO DE BIBLIOTECAS
// ==============================================================================
#include <WiFi.h>           
#include <PubSubClient.h>
#include <ESP32Servo.h>     

// ==============================================================================
// CONFIGURAÇÕES DE REDE WI-FI E MQTT
// Documentação WiFi - https://docs.wokwi.com/guides/esp32-wifi
// Conexão MQTT - https://www.hivemq.com/demos/websocket-client/
// ==============================================================================
const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883; 

const char* topic_publish = "wokwi/meuesp32/envio";
const char* topic_subscribe = "wokwi/meuesp32/recebimento";
String clientId = "ESP32Client-Wokwi-f78";

// ==============================================================================
// DEFINIÇÃO DOS PINOS E VALORES DE CALIBRAÇÃO DO LDR
// ==============================================================================
#define pinoLED 19         // LED indicador de Wi-Fi conectado
#define pinoServo 13       // Servo Motor da Persiana
#define pinoLDR 34         // Pino Analógico do LDR (ADC1)

// Valores da tabela de calibração conforme documentação
#define LDR_ESCURO 1016
#define LDR_CLARO  8

// ==============================================================================
// OBJETOS E VARIÁVEIS GERAIS
// ==============================================================================
WiFiClient espClient;               
PubSubClient client(espClient);     
Servo persianaServo;                
unsigned long lastMsg = 0;          

// ==============================================================================
// FUNÇÃO: CONECTAR AO WI-FI
// ==============================================================================
void setup_wifi() {
  delay(10);
  Serial.println(); 
  Serial.print("Conectando-se a rede: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password); 

  while (WiFi.status() != WL_CONNECTED) {
    delay(500); 
    Serial.print("."); 
  }
  
  // Acende o LED para indicar conexão Wi-Fi estabelecida
  digitalWrite(pinoLED, HIGH);
  
  Serial.println("");
  Serial.println("WiFi conectado com sucesso!");
  Serial.print("Endereço IP recebido: ");
  Serial.println(WiFi.localIP()); 
}

// ==============================================================================
// FUNÇÃO: CALCULAR LUMINOSIDADE (LDR)
// ==============================================================================
// Lê o sensor, aplica a fórmula de calibração e retorna a porcentagem tratada
float calcularLuminosidade() {
  // Leitura do LDR
  int valorLDR = analogRead(pinoLDR);

  // Converte a leitura para porcentagem.
  // IMPORTANTE: No LDR, a leitura diminui quando a luminosidade aumenta.
  float luminosidade = ((float)(LDR_ESCURO - valorLDR) / (LDR_ESCURO - LDR_CLARO)) * 100.0;

  // Limita entre 0 e 100%
  luminosidade = constrain(luminosidade, 0, 100);

  // Imprime no console para acompanhamento técnico
  Serial.print("Leitura LDR: ");
  Serial.print(valorLDR);
  // Exibe no Monitor Serial
  Serial.print(" | ");
  Serial.print("Luminosidade: ");
  Serial.println(String(luminosidade) + "%");

  return luminosidade;
}

// ==============================================================================
// FUNÇÃO: RECEBER MENSAGENS (CALLBACK) - CONTROLE DO SERVO
// ==============================================================================
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Mensagem recebida no tópico [");
  Serial.print(topic);
  Serial.print("]: ");
  
  String messageTemp; 
  
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]); 
    messageTemp += (char)payload[i]; 
  }
  Serial.println(); 
  
  // Lógica para abrir e fechar a persiana
  if (messageTemp == "Abrir") {
    persianaServo.write(180); 
    Serial.println("--> Comando aceito: Persiana ABERTA!");
  } 
  else if (messageTemp == "Fechar") {
    persianaServo.write(0);  
    Serial.println("--> Comando aceito: Persiana FECHADA!");
  }
}

// ==============================================================================
// FUNÇÃO: CONECTAR AO BROKER MQTT
// ==============================================================================
void reconnect() {
  while (!client.connected()) {
    Serial.print("Tentando conexão com o broker MQTT...");
    
    if (client.connect(clientId.c_str())) {
      Serial.println("Conectado ao broker!");
      client.publish(topic_publish, "ESP32 Conectado no Wokwi e pronto!");
      client.subscribe(topic_subscribe);
    } else {
      Serial.print("Falhou, erro=");
      Serial.print(client.state());
      Serial.println(" Tentando novamente em 5 segundos...");
      delay(5000); 
    }
  }
}

// ==============================================================================
// SETUP: EXECUTA UMA VEZ AO INICIAR
// ==============================================================================
void setup() {
  Serial.begin(115200); 
  
  // Configuração dos pinos de hardware
  pinMode(pinoLED, OUTPUT);    
  digitalWrite(pinoLED, LOW);  
  
  pinMode(pinoLDR, INPUT);
  analogReadResolution(12); // Define a resolução do ADC para 12 bits (0 a 4095)
  
  persianaServo.attach(pinoServo); 
  persianaServo.write(0);          // Inicia com a persiana fechada
  
  setup_wifi(); 
  client.setServer(mqtt_server, mqtt_port); 
  client.setCallback(callback); 
}

// ==============================================================================
// LOOP PRINCIPAL: EXECUTA CONTINUAMENTE
// ==============================================================================
void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  unsigned long now = millis(); 
  // Temporizador não bloqueante de 5 segundos
  if (now - lastMsg > 5000) {
    lastMsg = now; 
    // Chama a função isolada para obter o percentual de luz
    float luzCalculada = calcularLuminosidade();
    // Monta a string com o valor retornado pela função
    String msg = "Luminosidade: " + String(luzCalculada, 1) + "%";
    // Publica no broker MQTT
    client.publish(topic_publish, msg.c_str()); 
  }
}