/**
IFRJ Campus Volta Redonda - RJ
Pós graduação em Automação Industrial e Robótica
Desenvolvido pela aluna: Thayná Patricio
Professor Orientador: Profº Doutor Leonardo Vidal

Aula 2 - Prática 1
**/

// ==============================================================================
// INCLUSÃO DE BIBLIOTECAS
// ==============================================================================
#include <WiFi.h>           // Biblioteca nativa do ESP32 para gerenciar a conexão Wi-Fi
#include <PubSubClient.h>   // Biblioteca de terceiros (precisa ser instalada) para o protocolo MQTT

// ==============================================================================
// CONFIGURAÇÕES DE REDE WI-FI
// ==============================================================================
// No Wokwi, usamos a rede "Wokwi-GUEST", que simula uma conexão de internet.
// Não é necessário colocar senha.
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ==============================================================================
// CONFIGURAÇÕES DO BROKER MQTT (SERVIDOR)
// ==============================================================================
// Estamos usando um broker público e gratuito para testes. 
// ATENÇÃO: Como é público, qualquer pessoa pode ler mensagens nesses tópicos.
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883; // Porta padrão para comunicação MQTT sem criptografia

// ==============================================================================
// CONFIGURAÇÕES DE TÓPICOS MQTT
// ==============================================================================
// Tópico onde o ESP32 vai PUBLICAR (enviar) informações:
const char* topic_publish = "wokwi/meuesp32/envio";
// Tópico onde o ESP32 vai ASSINAR (escutar/receber) informações:
const char* topic_subscribe = "wokwi/meuesp32/recebimento";
// Todo cliente MQTT precisa de um ID único no mundo todo, você pode modificar os 4 digitos finais
String clientId = "ESP32Client-Wokwi-f78";

// ==============================================================================
// OBJETOS E VARIÁVEIS GERAIS
// ==============================================================================
WiFiClient espClient;               // Cria o objeto que gerencia a conexão de rede do ESP32
PubSubClient client(espClient);     // Passa o objeto de rede para a biblioteca MQTT
unsigned long lastMsg = 0;          // Variável para controlar o tempo (evitar uso da função delay)

// ==============================================================================
// FUNÇÃO: CONECTAR AO WI-FI
// ==============================================================================
void setup_wifi() {
  delay(10);
  Serial.println(); // Pula uma linha no monitor serial
  Serial.print("Conectando-se a rede: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password); // Inicia a tentativa de conexão com a rede Wi-Fi

  // Fica em um loop (preso aqui) até que o status mude para "CONECTADO"
  while (WiFi.status() != WL_CONNECTED) {
    delay(500); // Espera meio segundo antes de checar novamente
    Serial.print("."); // Imprime pontinhos no serial para mostrar que está carregando
  }

  // Se saiu do loop acima, é porque conectou com sucesso!
  Serial.println("");
  Serial.println("WiFi conectado com sucesso!");
  Serial.print("Endereço IP recebido: ");
  Serial.println(WiFi.localIP()); // Mostra o IP que o Wokwi atribuiu ao ESP32
}

// ==============================================================================
// FUNÇÃO: RECEBER MENSAGENS (CALLBACK)
// ==============================================================================
// Essa função é ativada AUTOMATICAMENTE sempre que chega uma mensagem no tópico assinado
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Mensagem recebida no tópico [");
  Serial.print(topic);
  Serial.print("]: ");
  
  String messageTemp; // Variável temporária para guardar a mensagem recebida
  
  // O "payload" chega como bytes. Este loop transforma os bytes em letras/caracteres.
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]); // Imprime letra por letra no monitor serial
    messageTemp += (char)payload[i]; // Junta as letras na nossa variável (caso queira usar depois)
  }
  Serial.println(); // Pula uma linha ao terminar de imprimir a mensagem
  
  // Exemplo de como usar a mensagem recebida:
  // if(messageTemp == "Ligar") {
  //   digitalWrite(PINO_DO_LED, HIGH);
  // }
}

// ==============================================================================
// FUNÇÃO: CONECTAR (E RECONECTAR) AO BROKER MQTT
// ==============================================================================
void reconnect() {
  // Fica em loop até conseguir se conectar ao Broker MQTT
  while (!client.connected()) {
    Serial.print("Tentando conexão com o broker MQTT...");
    
    // Tenta conectar usando o ID criado
    if (client.connect(clientId.c_str())) {
      Serial.println("Conectado ao broker!");
      
      // Assim que conecta, publica uma mensagem avisando que está online
      client.publish(topic_publish, "ESP32 Conectado no Wokwi e pronto!");
      
      // E em seguida, assina o tópico para começar a escutar mensagens de fora
      client.subscribe(topic_subscribe);
    } else {
      // Se deu erro na conexão, mostra o código do erro
      Serial.print("Falhou, erro=");
      Serial.print(client.state());
      Serial.println(" Tentando novamente em 5 segundos...");
      
      delay(5000); // Espera 5 segundos antes de tentar a conexão MQTT novamente
    }
  }
}

// ==============================================================================
// SETUP: RODA APENAS UMA VEZ AO LIGAR O ESP32
// ==============================================================================
void setup() {
  Serial.begin(115200); // Inicia a comunicação serial para vermos os logs (mesma velocidade do Wokwi)
  setup_wifi(); // Chama a função que conecta na internet
  // Configura a biblioteca MQTT com o endereço do servidor e a porta
  client.setServer(mqtt_server, mqtt_port); 
  // Diz para a biblioteca MQTT qual função rodar quando uma mensagem chegar
  client.setCallback(callback); 
}

// ==============================================================================
// LOOP: RODA REPETIDAMENTE ENQUANTO O ESP32 ESTIVER LIGADO
// ==============================================================================
void loop() {
  // 1. Checa se a conexão com o servidor MQTT caiu. Se caiu, tenta reconectar.
  if (!client.connected()) {
    reconnect();
  }
  // 2. Mantém a biblioteca MQTT rodando (processando envios, recebimentos e pings)
  client.loop();
  // 3. Temporizador não bloqueante para enviar uma mensagem a cada 5 segundos
  unsigned long now = millis(); // Pega o tempo atual em milissegundos desde que o ESP32 ligou
  // Se a diferença entre o tempo atual e o tempo da última mensagem for maior que 5000ms (5s):
  if (now - lastMsg > 5000) {
    lastMsg = now; // Atualiza a marcação de tempo para contar mais 5 segundos a partir de agora
    Serial.print("Publicando mensagem no tópico: ");
    Serial.println(topic_publish);
    // Monta a mensagem. Ex: "Contador de tempo Wokwi: 15s"
    String msg = "Contador de tempo Wokwi: " + String(now/1000) + "s";
    // Envia (publica) a mensagem para o broker MQTT
    // O c_str() converte a String para o formato de caracteres que a biblioteca MQTT exige
    client.publish(topic_publish, msg.c_str()); 
  }
}