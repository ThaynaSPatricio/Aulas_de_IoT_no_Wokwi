#include <WiFi.h>           // Biblioteca para conexão com WiFi
#include <HTTPClient.h>     // Biblioteca para requisições HTTP
#include <WiFiClientSecure.h> // Necessária para HTTPS (SSL)

// Dados da rede WiFi do Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";
// URL do webhook do n8n (substitua pela sua)
String webhook = "https://haynapatricio.app.n8n.cloud/webhook/aulaiotthayna";

void enviarEmail() {
  // Cria cliente seguro para HTTPS
  WiFiClientSecure client;
  // Ignora verificação de certificado SSL (necessário no Wokwi)
  client.setInsecure();
  HTTPClient http; // Cria objeto HTTP
  // Inicia conexão com o webhook usando o cliente seguro
  http.begin(client, webhook);
  // Define o tipo de conteúdo como JSON
  http.addHeader("Content-Type", "application/json"); 
  // Cria o corpo da requisição (mensagem que será enviada)
  String json = "{\"mensagem\":\"Conexão com ESP32 realizada!\"}";
  // Envia requisição POST com o JSON
  int httpCode = http.POST(json);
  // Mostra o código de resposta HTTP no monitor serial
  Serial.print("Código HTTP: ");
  Serial.println(httpCode);

  // Verifica se a requisição foi bem sucedida
  if (httpCode > 0) {
    Serial.println("Mensagem enviada com sucesso!");
  } else {
    Serial.println("Erro ao enviar.");
  }
  // Finaliza a conexão HTTP
  http.end();
}

void setup() {
  // Inicia comunicação serial (monitor serial)
  Serial.begin(115200);
  Serial.println("Conectando ao WiFi...");
  WiFi.begin(ssid, password); // Inicia conexão com a rede WiFi

  // Aguarda até conectar ao WiFi
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);              // Pequeno atraso
    Serial.print(".");       // Mostra progresso na tela
  }
  Serial.println("\nWiFi conectado!");
  // Após conectar, chama função para enviar o "email"
  enviarEmail();
}

void loop() {
  // Não é necessário repetir neste exemplo
}