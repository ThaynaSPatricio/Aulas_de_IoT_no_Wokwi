/**
IFRJ Campus Volta Redonda - RJ
Pós graduação em Automação Industrial e Robótica
Desenvolvido pela aluna: Thayná Patricio
Professor Orientador: Profº Doutor Leonardo Vidal

Aula 1 - Desafio Final
**/

// ===================== BIBLIOTECAS =====================

#include <WiFi.h> // WiFi → conexão com internet
#include <Adafruit_GFX.h> // Display TFT
#include <Adafruit_ILI9341.h>
#include <HTTPClient.h> // Requisições HTTP (API e webhook)
#include <ArduinoJson.h> // Manipulação de JSON (API clima)
#include <WiFiClientSecure.h> // HTTPS (necessário para webhook/email)
#include <DHT.h> // Sensor DHT22

// ===================== CONFIGURAÇÕES =====================

// WiFi do Wokwi (RNF01)
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// API OpenWeather (RNF02)
const String apiKey = "DIGITE SUA API KEY AQUI"; 
const String cidade = "DIGITE CIDADE ESCOLHIDA AQUI";
const String estado = "DIGITE O ESTADO AQUI";

// Webhook (n8n ou outro serviço de email / nuvem) (RF04)
String webhook = "DIGITE SUA URL AQUI";

// Periodicidade de leitura (RNF04)
const unsigned long INTERVALO_LEITURA = 15000; // 15 segundos para simulação
unsigned long ultimaLeitura = 0;

// ===================== DISPLAY TFT =====================
// Definição dos pinos do display
#define TFT_CS   5
#define TFT_DC   2
#define TFT_RST  4
// Cria objeto do display
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);

// ===================== SENSOR DHT22 =====================
#define DHTPIN 15 // Pino de dados (RF01)
#define DHTTYPE DHT22 // Tipo do sensor
DHT dht(DHTPIN, DHTTYPE); // Cria objeto do sensor

// ===================== LED que simula Exaustor =====================
#define motor 14 // Pino de dados alterado para o GPIO 14 (RF03)

// ===================== CONTROLE E MEMÓRIA =====================
bool alertaEnviado = false; // Evita envio repetido de alertas (spam)

// Variáveis para guardar as últimas medições enviadas (evita reenviar se os valores não mudarem)
float ultimaTempInt = -999.0;
float ultimaUmidInt = -999.0;
float ultimaTempExt = -999.0;
float ultimaUmidExt = -999.0;

// ===================== ESTRUTURAS =====================
// Estrutura para armazenar dados da API
struct ClimaAPI {
  String cidade;
  String temperatura;
  String umidade;
  bool sucesso; // Flag de validação para fail-safe
};
// Estrutura para armazenar dados do sensor
struct ClimaAmbiente {
  float temperatura;
  float umidade;
  bool erro; // Flag de validação para fail-safe
};

// ===================== FUNÇÃO WIFI =====================

void conectarWiFi() {
  // Tela inicial
  tft.fillScreen(ILI9341_BLACK);
  tft.setCursor(20, 100);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setTextSize(2);
  tft.println("Conectando WiFi...");
  
  // Inicia conexão (RNF01)
  WiFi.begin(ssid, password);
  
  int tentativas = 0;
  // Aguarda conexão
  while (WiFi.status() != WL_CONNECTED && tentativas < 20) {
    delay(200);
    Serial.print(".");
    tentativas++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi OK!");
    // Confirmação na tela
    tft.fillScreen(ILI9341_BLACK);
    tft.setTextColor(ILI9341_GREEN);
    tft.setCursor(20, 100);
    tft.println("WiFi OK!");
  } else {
    Serial.println("\nFalha no WiFi!");
    tft.fillScreen(ILI9341_BLACK);
    tft.setTextColor(ILI9341_RED);
    tft.setCursor(20, 100);
    tft.println("WiFi Erro!");
  }
}

// ===================== LEITURA DHT =====================

ClimaAmbiente lerDHT() {
  ClimaAmbiente clima;
  clima.erro = false;
  
  // Lê temperatura e umidade (RF01)
  clima.temperatura = dht.readTemperature();
  clima.umidade = dht.readHumidity();
  
  // Verifica erro de leitura
  if (isnan(clima.temperatura) || isnan(clima.umidade)) {
    Serial.println("Erro DHT22 (RF05)");
    // Define valores padrão em caso de erro
    clima.temperatura = 0;
    clima.umidade = 0;
    clima.erro = true;
  }
  return clima;
}

// ===================== API CLIMA =====================

ClimaAPI obterClimaAPI() {
  ClimaAPI clima;
  // Valores padrão
  clima.cidade = cidade;
  clima.temperatura = "--";
  clima.umidade = "--";
  clima.sucesso = false;

  // Só executa se estiver conectado
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    // Monta URL da API (RF02)
    String url = "http://api.openweathermap.org/data/2.5/weather?q=" 
                 + cidade + "," + estado + "&appid=" + apiKey + "&units=metric";
    http.begin(url);

    // Faz requisição GET (RF02)
    int httpCode = http.GET();
    if (httpCode > 0) {
      // Recebe resposta JSON
      String payload = http.getString();
      Serial.println(payload); // RF05: Monitor Serial
      
      // Processa JSON
      DynamicJsonDocument doc(1024);
      deserializeJson(doc, payload);
      
      // Verifica se deu certo
      if (doc["cod"] == 200) {
        clima.cidade = doc["name"].as<String>();
        clima.temperatura = String((float)doc["main"]["temp"], 1);
        clima.umidade = String((int)doc["main"]["humidity"]);
        clima.sucesso = true;
      }
    }
    http.end();
  }
  return clima;
}

// ===================== DETECÇÃO DE ALERTA E LÓGICA EXAUSTOR =====================

bool temAlerta(ClimaAPI api, ClimaAmbiente amb) {
  float tempAPI = api.temperatura.toFloat();
  float umidAPI = api.umidade.toFloat();
  
  // Diferença entre API e ambiente
  bool diferencaTemp = abs(tempAPI - amb.temperatura) >= 20;
  bool diferencaUmid = abs(umidAPI - amb.umidade) >= 20;
  // Verifica faixa segura de temperatura
  bool tempForaRange = (amb.temperatura < 20 || amb.temperatura > 35);
  // Retorna se houver qualquer alerta
  return (diferencaTemp || diferencaUmid || tempForaRange);
}

// Lógica de acionamento do exaustor baseada nos Requisitos RF03 e RNF03
bool controlarExaustor(ClimaAPI api, ClimaAmbiente amb) {
  // RNF03: Resiliência (Falha Segura). Se falhar a leitura ou perder WiFi, desliga por segurança
  if (amb.erro || !api.sucesso || WiFi.status() != WL_CONNECTED) {
    digitalWrite(motor, LOW);
    Serial.println("Exaustor DESLIGADO por Seguranca (Fail-Safe RNF03)");
    return false;
  }

  float umidExterna = api.umidade.toFloat();
  float umidSilo = amb.umidade;

  // RF03: O sistema deve acionar o LED (Exaustor) se: (Umidade Silo > 40%) E (Umidade Externa < Umidade Silo)
  bool ligarExaustor = (umidSilo > 40.0) && (umidExterna < umidSilo);

  digitalWrite(motor, ligarExaustor ? HIGH : LOW);
  return ligarExaustor;
}

// ===================== FORMATADOR DE MENSAGEM DO DISPLAY =====================

// Monta o texto exatamente igual ao exibido na tela para envio no e-mail
String montarTextoDisplay(ClimaAPI api, ClimaAmbiente amb, bool alerta, bool exaustorStatus) {
  String texto = "";
  if (alerta) {
    texto += "ALERTA! <br><br>";
  }
  texto += api.cidade + " - " + estado + "<br><br>";
  texto += "CLIMA DA CIDADE<br>";
  texto += "Temp: " + api.temperatura + " C<br>";
  texto += "Umid: " + api.umidade + "%<br><br>";
  texto += "CLIMA SILO (INTERNO)<br>";
  texto += "Temp: " + String(amb.temperatura, 1) + " C<br>";
  texto += "Umid: " + String(amb.umidade, 1) + "%<br><br>";
  texto += "EXAUSTOR: " + String(exaustorStatus ? "LIGADO" : "DESLIGADO");
  return texto;
}

// ===================== ENVIO DE ALERTA E DADOS NA NUVEM ===============

void enviarEmail(String mensagem) {
  // Cliente seguro HTTPS
  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;

  // Inicia conexão com webhook
  http.begin(client, webhook);
  http.addHeader("Content-Type", "application/json");

  // Evita quebra de JSON por caracteres inválidos
  mensagem.replace("\"", "'");

  // Monta JSON (apenas uma vez)
  String json = "{\"mensagem\":\"" + mensagem + "\"}";

  // Envia POST
  int httpCode = http.POST(json);

  Serial.print("JSON enviado: ");
  Serial.println(json);
  Serial.print("HTTP: ");
  Serial.println(httpCode);

  http.end();
}

// Envio dos dados consolidados em formato JSON para serviço de nuvem (RF04 & RNF05)
void enviarDadosNuvem(ClimaAPI api, ClimaAmbiente amb, bool exaustorAtivo) {
  if (WiFi.status() != WL_CONNECTED) return;

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;
  http.begin(client, webhook);
  http.addHeader("Content-Type", "application/json");

  // RF04 & RNF05: JSON estruturado e escalável com dados internos e externos
  DynamicJsonDocument doc(512);
  
  JsonObject interno = doc.createNestedObject("silo_interno");
  interno["temperatura"] = amb.temperatura;
  interno["umidade"] = amb.umidade;

  JsonObject externo = doc.createNestedObject("clima_externo");
  externo["cidade"] = api.cidade;
  externo["temperatura"] = api.temperatura.toFloat();
  externo["umidade"] = api.umidade.toFloat();

  doc["exaustor_ligado"] = exaustorAtivo;
  doc["timestamp"] = millis();

  String jsonPayload;
  serializeJson(doc, jsonPayload);

  int httpCode = http.POST(jsonPayload);
  Serial.print("Payload Consolidado enviado a Nuvem (RF04): ");
  Serial.println(jsonPayload);
  Serial.print("HTTP Status: ");
  Serial.println(httpCode);

  http.end();
}

// ===================== VERIFICA ALERTAS =====================

void verificarAlertas(ClimaAPI api, ClimaAmbiente amb, bool exaustorStatus) {
  bool alerta = temAlerta(api, amb);

  float tempExtAtual = api.temperatura.toFloat();
  float umidExtAtual = api.umidade.toFloat();

  // Verifica se qualquer valor medido sofreu alteração desde o último envio
  bool valoresMudaram = (amb.temperatura != ultimaTempInt) ||
                        (amb.umidade != ultimaUmidInt) ||
                        (tempExtAtual != ultimaTempExt) ||
                        (umidExtAtual != ultimaUmidExt);

  // Só envia e-mail se houver um alerta ativo E os valores tiverem mudado
  if (alerta && valoresMudaram) {

    // Gera a exata mesma mensagem visual do display
    String textoDisplay = montarTextoDisplay(api, amb, alerta, exaustorStatus);

    // Envia o texto por e-mail
    enviarEmail(textoDisplay);

    // Atualiza o histórico das últimas medições enviadas
    ultimaTempInt = amb.temperatura;
    ultimaUmidInt = amb.umidade;
    ultimaTempExt = tempExtAtual;
    ultimaUmidExt = umidExtAtual;

    alertaEnviado = true;
  }

  // Se o estado voltou ao normal, permite novo envio quando um alerta futuro ocorrer
  if (!alerta) {
    alertaEnviado = false;
  }
}

// ===================== DISPLAY =====================

void setDisplay(ClimaAPI api, ClimaAmbiente amb, bool alerta, bool exaustorStatus) {
  // Fundo muda de cor conforme alerta
  tft.fillScreen(alerta ? ILI9341_RED : ILI9341_BLACK);
  tft.setTextSize(2);
  tft.setTextColor(ILI9341_WHITE);

  // Exibe aviso grande
  if (alerta) {
    tft.setTextSize(3);
    tft.setCursor(10, 10);
    tft.println("ALERTA!");
    tft.setTextSize(2);
  }
  int yOffset = alerta ? 40 : 10;
  // Cidade
  tft.setCursor(10, yOffset);
  tft.print(api.cidade + " - " + estado);

  // Dados da API
  tft.setTextColor(ILI9341_CYAN);
  tft.setCursor(10, yOffset + 30);
  tft.println("CLIMA DA CIDADE");
  tft.setCursor(10, yOffset + 50);
  tft.print("Temp: " + api.temperatura + " C");
  tft.setCursor(10, yOffset + 70);
  tft.print("Umid: " + api.umidade + "%");

  // Dados do sensor
  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(10, yOffset + 100);
  tft.println("CLIMA SILO (INTERNO)");
  tft.setCursor(10, yOffset + 120);
  tft.print("Temp: " + String(amb.temperatura, 1) + " C");
  tft.setCursor(10, yOffset + 140);
  tft.print("Umid: " + String(amb.umidade, 1) + "%");

  // Status Exaustor (RF03 / RF05)
  tft.setTextColor(exaustorStatus ? ILI9341_GREEN : ILI9341_ORANGE);
  tft.setCursor(10, yOffset + 170);
  tft.print("EXAUSTOR: ");
  tft.println(exaustorStatus ? "LIGADO" : "DESLIGADO");
}

// ===================== SETUP =====================

void setup() {
  Serial.begin(115200); // RF05: Monitor Serial
  // Configuração do pino do motor/LED do exaustor
  pinMode(motor, OUTPUT);
  digitalWrite(motor, LOW); // Garante estado inicial desligado (RNF03)
  // Inicializa display
  tft.begin();
  tft.setRotation(0);
  // Inicializa sensor
  dht.begin();
  // Conecta no WiFi
  conectarWiFi();
}

// ===================== LOOP =====================

void loop() {
  unsigned long tempoAtual = millis();
  // RNF04: Controle por temporizador não-bloqueante (evita travar a execução)
  if (tempoAtual - ultimaLeitura >= INTERVALO_LEITURA) {
    ultimaLeitura = tempoAtual;
    // Reconexão automática em caso de queda (RNF03)
    if (WiFi.status() != WL_CONNECTED) {
      conectarWiFi();
    }
    // Lê sensor (RF01)
    ClimaAmbiente ambiente = lerDHT();
    // Lê API (RF02)
    ClimaAPI api = obterClimaAPI();
    // Controle e acionamento do Exaustor (RF03 / RNF03)
    bool exaustorLIG = controlarExaustor(api, ambiente);
    // Verifica alerta
    bool alerta = temAlerta(api, ambiente);
    // Envia email de alerta apenas se houver alerta E os valores tiverem mudado
    verificarAlertas(api, ambiente, exaustorLIG);
    // Envia dados consolidados para a nuvem em formato JSON (RF04)
    enviarDadosNuvem(api, ambiente, exaustorLIG);
    // Atualiza tela (RF05)
    setDisplay(api, ambiente, alerta, exaustorLIG);
  }
}